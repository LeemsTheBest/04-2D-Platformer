# Exercise-02d-Godot-Template
Exercise for MSCH-C220, 15 February 2021

A Godot Project Template, for use in future projects.

## Implementation
Built using Godot 3.2.3
Includes WASD mappings (up, left, down, right) and escape to quit.

## References
None

## Future Development
None

## Created by 
Liam O'Brien
